const botaoAbrir = document.getElementById('abrir-popup');
const conteudoPopup = document.getElementById('conteudo-popup');
const botaoFechar = document.getElementById('fechar-popup');

botaoAbrir.addEventListener('click', () => {
    conteudoPopup.style.display = 'flex'; /* Exibe o pop-up */
});

botaoFechar.addEventListener('click', () => {
    conteudoPopup.style.display = 'none'; /* Oculta o pop-up */
});

// Adicionei um evento de clique no fundo para fechar o pop-up se o usuário clicar fora do pop-up
conteudoPopup.addEventListener('click', (event) => {
    if (event.target === conteudoPopup) {
        conteudoPopup.style.display = 'none';
    }
});